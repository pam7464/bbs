package notice;

public class Notice {
	
	private int noticeID;
	private String noticeTit;
	private String noticeContent;
	private String noticeName;
	private String noticeDate;
	
	public int getNoticeID() {
		return noticeID;
	}
	public void setNoticeID(int noticeID) {
		this.noticeID = noticeID;
	}
	public String getNoticeTit() {
		return noticeTit;
	}
	public void setNoticeTit(String noticeTit) {
		this.noticeTit = noticeTit;
	}
	public String getNoticeContent() {
		return noticeContent;
	}
	public void setNoticeContent(String noticeContent) {
		this.noticeContent = noticeContent;
	}
	public String getNoticeName() {
		return noticeName;
	}
	public void setNoticeName(String noticeName) {
		this.noticeName = noticeName;
	}
	public String getNoticeDate() {
		return noticeDate;
	}
	public void setNoticeDate(String noticeDate) {
		this.noticeDate = noticeDate;
	}
	
	
}
